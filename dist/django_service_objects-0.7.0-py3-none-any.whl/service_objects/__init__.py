"""Service objects for Django"""

__version__ = '0.7.0'
__license__ = 'MIT License'
